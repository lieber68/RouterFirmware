#! /bin/sh

source /koolshare/scripts/base.sh
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y年%m月%d日\ %X)】:'

echo_date "========================= 重要说明 ============================="
echo_date "本程序用以放宽【虚拟内存】和【Jffs2USB】插件对U盘读写的速度限制"
echo_date "原程序【虚拟内存】限制，读速为20M/s,写速度为30M/s"
echo_date "原程序【Jffs2USB】限制，读速为20M/s,写速度为35M/s"
echo_date "本程序统一将读/写速度限制改为10M/s"
echo_date "如果您的U盘连这个速度都达不到，请将其丢进垃圾箱！！"
echo_date "================================================================"
sleep 1s
echo_date ""
echo_date ""
echo_date ""
echo_date "=====================  开始处理【虚拟内存】 ===================="
echo_date "请尽量使用速度达标的U盘，否则可能会影响路由稳定性"
echo_date "使用本程序前，请先安装对应插件"
echo_date "如果您未安装【虚拟内存】，请忽略下面的报错信息"

sed -i 's/R_LIMIT=20/R_LIMIT=10/g;s/W_LIMIT=30/W_LIMIT=10/g' /koolshare/scripts/swap_make.sh
sleep 1s
echo_date "=====================  【虚拟内存】处理完成 ===================="
echo_date ""
echo_date ""
echo_date ""
echo_date "=====================  开始处理【Jffs2USB】 ===================="
echo_date "极度不建议在速度不达标的U盘上，使用【Jffs2USB】"
echo_date "！！！低速U盘会严重影响路由稳定性，请慎重考虑！！！"
echo_date "！！！低速U盘会严重影响路由稳定性，请慎重考虑！！！"
echo_date "！！！低速U盘会严重影响路由稳定性，请慎重考虑！！！"
echo_date "如果您未安装【Jffs2USB】，请忽略下面的报错信息"

sed -i 's/R_LIMIT=20/R_LIMIT=10/g;s/W_LIMIT=35/W_LIMIT=10/g' /koolshare/scripts/usb2jffs_config.sh
sleep 1s
echo_date "=====================  【Jffs2USB】处理完成 ===================="

dbus set crackspeed_version="1.0"
dbus set softcenter_module_crackspeed_version="1.0"
dbus set softcenter_module_crackspeed_description="已经没用了，请卸载我！！"
dbus set softcenter_module_crackspeed_install="1"
dbus set softcenter_module_crackspeed_name="crackspeed"
dbus set softcenter_module_crackspeed_title="crackspeed"


sleep 1s
echo_date "======================================"
echo_date "=== 现在您可以在软件中心卸载本程序 ==="
echo_date "=== 卸载后并不会影响之前的修改操作 ==="
echo_date "===   出走的图标，直接卸了就可以   ==="
echo_date "===   破了的图标，直接卸了就可以   ==="
echo_date "======================================"
